import firebase from "firebase/compat/app";
import 'firebase/compat/auth';
import 'firebase/compat/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyCTFff2GNR-BXmqEobdDV1RGseQCaJIzUs",
  authDomain: "loginlogout-b42b0.firebaseapp.com",
  projectId: "loginlogout-b42b0",
  storageBucket: "loginlogout-b42b0.appspot.com",
  messagingSenderId: "223670393204",
  appId: "1:223670393204:web:aa797c94b4eee279a07421",
  measurementId: "G-T8BJYWJP2Q"
};
const firebaseApp = firebase.initializeApp(firebaseConfig);

const db = firebaseApp.firestore();
const auth = firebase.auth();

export { db, auth };